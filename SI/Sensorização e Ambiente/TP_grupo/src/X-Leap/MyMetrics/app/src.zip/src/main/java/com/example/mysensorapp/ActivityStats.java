package com.example.mysensorapp;

public class ActivityStats {
    private int activitytime;
    private int day;
    private int month;

    public ActivityStats() {
    }

    public int getActivitytime() {
        return activitytime;
    }

    public void setActivitytime(int activitytime) {
        this.activitytime = activitytime;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }
}
