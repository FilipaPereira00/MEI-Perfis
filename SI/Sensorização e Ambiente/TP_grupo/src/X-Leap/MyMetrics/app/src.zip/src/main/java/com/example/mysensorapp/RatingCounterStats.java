package com.example.mysensorapp;

public class RatingCounterStats {
    private int r00;
    private int r05;
    private int r10;
    private int r15;
    private int r20;
    private int r25;
    private int r30;
    private int r35;
    private int r40;
    private int r45;
    private int r50;

    public RatingCounterStats() {
    }

    public int getR00() {
        return r00;
    }

    public void setR00(int r00) {
        this.r00 = r00;
    }

    public int getR05() {
        return r05;
    }

    public void setR05(int r05) {
        this.r05 = r05;
    }

    public int getR10() {
        return r10;
    }

    public void setR10(int r10) {
        this.r10 = r10;
    }

    public int getR15() {
        return r15;
    }

    public void setR15(int r15) {
        this.r15 = r15;
    }

    public int getR20() {
        return r20;
    }

    public void setR20(int r20) {
        this.r20 = r20;
    }

    public int getR25() {
        return r25;
    }

    public void setR25(int r25) {
        this.r25 = r25;
    }

    public int getR30() {
        return r30;
    }

    public void setR30(int r30) {
        this.r30 = r30;
    }

    public int getR35() {
        return r35;
    }

    public void setR35(int r35) {
        this.r35 = r35;
    }

    public int getR40() {
        return r40;
    }

    public void setR40(int r40) {
        this.r40 = r40;
    }

    public int getR45() {
        return r45;
    }

    public void setR45(int r45) {
        this.r45 = r45;
    }

    public int getR50() {
        return r50;
    }

    public void setR50(int r50) {
        this.r50 = r50;
    }
}
